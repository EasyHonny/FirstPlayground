//: Playground - noun: a place where people can play

import UIKit

// Swift不需要main函数的入口，编译器会在全局函数自动设置程序的入口，在书写Swift代码时，可以不使用";"作为语句的结束标志
//var str = "Hello, playground"
//var str1 = "Hello, liuyansong"
//print("Hello World!") // Swift2.0使用的输出语句（在Swift1.2版本中也可以使用）
//// println("Hello World!") // Swift1.2及以前的版本使用的输出语句
//
//
//
//// 在Swift中，我们不需要给定常量和变量的数据类型，编译器会根据后面的赋值自动推测其数据类型，在某些情况下我们需要给定常量或变量的数据类型，这个时候我们只需要在常量/变量名称后边添加":"
//// -----------常量-----------
//// 使用let关键字进行定义
//
//// 定义形式1：let 常量名 = 常量值
//let a = 10
//
//// 定义形式2：let 常量名 : 数据类型 = 常量值
//let b: Int8 = 11
//
//
//
//// ------------变量-------------
//// 使用var关键字进行定义
//
//// 定义形式：var 变量名 = 变量值
//var c = 12
//
//// 定义形式：var 变量名 : 数据类型 = 变量值
//var d: Float = 13
//
//// Swift常量/变量命名规范更开放，几乎支持所有Unicode编码，我们甚至可以使用中文进行命名
//var 哈哈 = "呵呵"
//print(哈哈)
//
//// 运算 在Swift中不支持隐式转换数据类型，必须显示转换
//var sum = Float(c) + d
//print("呵呵 is " + "\(c)")
//print("呵呵 is \(c)")
//
//
//
//// ------------元组-------------
////var person = (name : "张三", age : 99, sex : "男")
////person.0
////person.1
////person.2
////
////person.name = "李四"
////person.age
////person.sex
//var person = (name: "张三",age:99,sex : "男")
//person.0
//person.1
//person.2
//person.name
//person.age = 88
//person.sex
//
//// ------------数组-------------
//// Swift中的数组要求每个元素的数据类型必须是统一的，如果数据类型不统一，将会自动转换成OC中的数组
//
//// let定义的是不可变数组，var定义的是可变数组
//
//// 定义形式 ： let/var 数组名称 : [数组元素类型] = 数组的值 ps : "[数组元素类型]"可省略不写
//
//// 定义一个空数组
//var emptyArray : [String] = [String]()
//var 黑名单 = ["张涛", "白昊"]
//黑名单.append("尚仁杰")
//黑名单.insert("葛德福", at: 2)
//黑名单.insert("金鑫亮", at: 2)
//黑名单.remove(at: 2)
//
//// 取某个范围
//// 0...2 代表0到2的闭区间
//黑名单[0...2]
//
//// 0..<2 代表0到2的左闭右开区间
//黑名单[0..<2]
//
//// ------------字典-------------
//
//// 在Swift中要求字典中的key必须是统一类型，value必须是统一类型，key和value可以是不同一类型，如果存放不同类型，会自动转化成OC中的字典
//
//// 创建一个空字典
//
//// 形式1：(推荐)
//var emptyDic1 = [String: Int]()
//
//// 形式2：
//var emptyDic2 = Dictionary<String, Int>()
//
//var personDic = ["age": 11, "num": 99]
//// 取值：可以通过key直接获取，写法和OC中字面量的写法类似
//personDic["age"]
//// 更改：直接取出对应的value进行更改值的操作
//personDic["age"] = 22;
//// 添加：如果key不存在，会直接向字典中追加该键值对
//personDic["number"] = 10
//// 删除：通过key值删除对应的键值对
//personDic.removeValue(forKey: "age")
//personDic
//
//
//// ------------if语句-------------
//
//// if的判断条件要求必须是布尔表达式，也就是说以前我们熟悉的if(变量)的写法，在Swift中不再隐式转化为布尔值，另外，if的判断条件可以不写括号
//if 0 == a {
//    print(a)
//} else if 1 == a {
//    print(a)
//} else {
//    print(a)
//}
//
//
//// ------------循环-------------
//var count = 10
//while count > 5 {
//    count -= 1
//}
//
//// repeat-while (ps : 相当于do-while)
//repeat {
//    count -= 1
//} while count > 0
//
///*
//// Swift 1.2写法
//do {
//    count--;
//} while count > 0
//*/
//
//// for循环
//for i in 0 ..< 10 {
//    print(i)
//}
//
//var 🌍 = ["🐱", "🐶", "🐷", "🐫", "🐂", "🐎", "🐑", "🐒", "🐯", "🐭", "💩", "老白"]
//// for-in
//for something in 🌍 {
//    print(something)
//}
//
//for i in 0...10 {
//    print(i)
//}
//
//
//// ------------可选变量(optional变量)-------------
//// 可选变量的意图在于某一个变量的值在使用过程中，可能为空，我们需要做一个声明
//var string = "123"
//var number : Int? = Int(string)
//if nil != number {
//    print(number!) //!为可选变量的拆包，告诉编译器，此时我确定其一定有值
//} else {
//    print("number 为nil")
//}
//
//// 第二种判断可选变量是否为空的方式，如果number为空，常量n将会初始化失败，代码执行else中的内容，如果number不为空，常量n初始化成功，在该条件对应的执行代码中，可以使用n
//if let n = number {
//    print(n)
//} else {
//    print("number为空")
//}
//
//// 在使用可选变量时，我们可能不想使用空值，所以我们可以给可选变量赋一个默认值，当可选变量为空时，取默认值
//var string1 = "abc"
//var number1 : Int? = Int(string1)
//var finalNumber = number1 ?? 0
//print(finalNumber)
//
//
//// switch
//// Swift中对switch的写法做了优化，我们可以不写选择条件的括号，可以不写break(ps:默认我们执行break操作)，如果我们想强行执行下一个case，需要使用fallthrough关键字，要求必须有default
//var caseNumber = 0
//switch caseNumber {
//case 0:
//    print("选择了0")
//    fallthrough
//case 1:
//    print("选择了1")
//default:
//    print("选择了其它")
//}
//
//// case的条件可以为字符串
//var caseString = "老白"
//switch caseString {
//case "张涛":
//    print("选择了张涛")
//    fallthrough
//case "老白":
//    print("选择了老白")
//default:
//    print("选择了其它")
//}
//
//// case条件可以是一个范围，且这个范围是可以交叉的，如果同时满足多个选择条件，会执行第一个，我们可以使用"where"关键字附加选择所匹配的条件
//var caseNumber1 = 10
//switch caseNumber1 {
//case 0...5:
//    print("0到5之间的数")
//case let x where 10 == x:
//    print(x)
//case 4..<11:
//    print("大于等于4小于11的数")
//default:
//    print("other")
//}
//
//
//// case的条件还可以是一个元组
//var point = (10, 20)
//switch point {
//case (0, 0):
//    print("在原点")
//case (_, 0):
//    print("在x上")
//case (0, _):
//    print("在y上")
//default:
//    print("不在坐标轴上")
//}
//
//
//
//// ------------函数-------------
//// 定义形式：func 函数名 （参数列表）->返回值
//// 内部可以访问的参数叫做内部参数，外部调用时可以看见的标签叫做外部参数，在Swift2.0中，默认第一个参数是没有外部标签的，之后的参数会自动生成和内部参数名相同的外部参数
//// 定义一个无参无返回值的函数
//func sayHello() {
//    print("Hello")
//}
//
//sayHello()
//
//// 有参数无返回值
//func sayHello(name:String) {
//    print("呵呵\(name)")
//}
//
//sayHello(name: "老白")
//
//// 有参数有返回值
////func sayHello1(name1:String, name2:String)->String {
////    return "呵呵," + name1 + name2
////}
//
////var result = sayHello1("老白,", name2: "SB")
//func sayHello1(name1:String,name2:String)->String
//{
//return "呵呵" + name1 + name2
//}
//    var result = sayHello1(name1: "老白", name2: "SB")
//
//
//// 我们可以给参数添加对应的外部标签，不添加则使用默认设置
//func sayHello2(PersonName1 name1:String, PersonName2 name2:String, name3:String)-> String {
//    return "呵呵" + name1 + name2 + name3
//}
//var result2 = sayHello2(PersonName1: "老白", PersonName2: "💩", name3: "SB")
//
//// 在Swift1.2中的写法
////
////func sayHello2(PersonName1 name1:String, PersonName2 name2:String, #name3:String)->String {
////    return "呵呵" + name1 + name2 + name3
////}
////var result2 = sayHello2(PersonName1: "老白", PersonName2: "💩", name3: 💩)
//
//
//// 多参数的函数（ps:不确定参数个数的）
//func sum(numbers: Int...) -> Int {
//    var sumResult = 0
//    for i in numbers {
//        sumResult += i
//    }
//    return sumResult
//}
//
//sum(numbers: 1, 2, 3)
//
//// 
//var value = 10
//func changeValue( num: inout Int)
//{
//    num = 20
//}
//changeValue(num: &value)
//
//
//var compareNumber = 20
//var numberArray = [3, 46, 5, 17, 25, 36, 48, 59]
//
//
//func sortNumbers(compare: Int, numbers: [Int])->[Int] {
//    var resultArray : [Int] = [Int]()
//    for num in numbers {
//        if num > compareNumber {
//            resultArray.append(num)
//        }
//    }
//    return resultArray
//}
//
//
//sortNumbers(compare: compareNumber, numbers: numberArray)
//
//// ------------闭包函数-------------
//// 相当于OC中的block
//// 闭包的声明：（参数列表）——> 返回值
//// 闭包的定义：{(参数列表) ——> 返回值 in 函数体}
//
//func sortNumbersFinish(compare: Int, numbers: [Int], cb:(_ num1: Int, _ num2: Int)->Bool ) -> [Int] {
//    var resultArray = [Int]() // 创建一个空数组，用于接收满足条件的结果
//    for num in numbers { // 遍历传进来的数组，获取数组中的每一个数字，用来做比较
//        if cb(num, compare) { // 带两个参数和一个返回值的函数参数
//            resultArray.append(num)
//        }
//    }
//    return resultArray
//}
//
//// 完整地闭包函数，cb : 带两个参数和一个返回值的函数参数
//sortNumbersFinish(compare: compareNumber, numbers: numberArray, cb: {(num1: Int, num2: Int)->
//    Bool
//    in
//    return num1 > num2
//})
//
//
//// 可以不写闭包函数的参数类型，编译器会根据传进来的参数自动推测出参数的类型
//sortNumbersFinish(compare: compareNumber, numbers: numberArray, cb: {(num1, num2)->Bool in
//    return num1 > num2
//})
//
//// 可以不写返回值类型，编译器会根据最后一行的表达式的返回值作为闭包函数的返回值
//sortNumbersFinish(compare: compareNumber, numbers: numberArray, cb: {(num1, num2) in
//    num1 > num2
//})
//
//// 可以不写闭包参数的声明，"$0"代表闭包函数的第0个参数，"$1"代表闭包函数的第1个参数
//sortNumbersFinish(compare: compareNumber, numbers: numberArray, cb: {$0 > $1})
//
//
//// 此需求还可以进一步简写，">"代表两个数做比较
//sortNumbersFinish(compare: compareNumber, numbers: numberArray, cb: > )
//
//// 尾随闭包(推荐)：当闭包函数作为函数的最后一个参数的时候，可以把这个闭包函数放到函数列表的外边
//// 当函数参数列表中只有一个闭包函数参数时，参数列表的小括号也可以不写:函数名{闭包函数}
//sortNumbersFinish(compare: compareNumber, numbers: numberArray) { (num1, num2) -> Bool in
//    return num1 > num2
//}
//
//
//// *******************结构体*********************
//// Swift中的结构体跟类很相似，都有自己的属性和方法，甚至可以有构造器（ps:init），这点和OC中的结构体有很大不同
//// Swift中的结构体和类的不同点：
//// 1.结构体是值类型，类是引用类型（ps:引用类型，操作内存本身，是对内存的引用。值类型，拷贝出一个新的相等的值去使用）
//// 2.类可以被继承，结构体不可以被继承
//// 3.类有析构器，结构体没有（ps:析构器我们可以理解为ARC下得dealloc方法，可以在里面做释放资源的操作）
//
//struct Car {
//    var brand = "奥迪双钻"
//    func run() {
//        print("I am \(brand), I am running!")
//    }
//    
//    // 构造器(ps:相当于OC中的初始化方法),如果我们不自定义构造器方法，结构体会为我们自动生成构造器方法
//    init(brand: String){
//        self.brand = brand
//    }
//}
//
//var myCar = Car(brand: "奥拓")
//myCar.run()
//
//struct Point {
//    var x = 0.0
//    var y = 0.0
//}
//
//struct Size {
//    var width = 0.0
//    var height = 0.0
//}
//
//struct Rect {
//    var origin = Point()
//    var size = Size()
//    // 计算属性
//    var center:Point {
//        get {
//            let centerX = origin.x + size.width * 0.5
//            let centerY = origin.y + size.height * 0.5
//            return Point(x: centerX, y: centerY)
//        }
//        set {
//            origin.x = newValue.x - size.width * 0.5
//            origin.y = newValue.y - size.height * 0.5
//        }
//    }
//    
//    init(x: Double, y: Double, width: Double, height: Double) {
//        self.origin = Point(x: x, y: y)
//        self.size = Size(width: width, height: height)
//    }
//}
//
//var frame = Rect(x: 0, y: 0, width: 100, height: 100)
//frame.center.x
//frame.center.y
//
//frame.center = Point(x: 200, y: 100)
//frame.origin.x
//frame.origin.y
//
//
//// ********************类*********************
//// Swift中不要求有根类，所以可以没有继承关系
//class People {
//    //var name = ""
//    var name: String
//    var age: Int?
//    
//    init(name: String, age: Int) {
//        self.name = name
//        //self.age = age
//    }
//    
//    func sayHello() {
//        print("My name is \(self.name), I am \(self.age) years old!")
//    }
//    
//    // 类方法
//    class func sayByeBye() {
//        print("bye bye")
//    }
//}
//
//var people = People(name: "哈哈", age: 20)
//people.name
//people.age
//people.sayHello()
//People.sayByeBye()
//
//class Student: People {
//    var number = 0
//    init(name: String, age: Int, number: Int) {
//        self.number = number
//        super.init(name: name, age: age)
//    }
//    override func sayHello() {
//        print("My name is \(self.name), I am \(self.age) years old!, my number is \(self.number).")
//    }
//}
//
//// *********************协议**********************
//protocol A {
//    func sayHeHe()
//}
//
//class LanOuStudent: Student, A {
//    func sayHeHe() {
//        print("He He 老白")
//    }
//}

// Swift3.0
// 从第一个参数就必须指定参数名，除非使用"_"明确指出省略参数
func sum1 (num1: Int, num2: Int) -> Int {
    return num1 + num2
}
//
sum1(num1: 1, num2: 2)

// inout 参数修饰 改放到类型前, 取消 var参数
func increase( a: inout Int) {
    
    
}

// 方法返回值
// Swift 3.0 中方法的返回值必须有接收否则会报警告，当然其实主要目的是为了避免开发人员忘记接收返回值的情况，但是有些情况下确实不需要使用返回值可以使用"_"接收来忽略返回值。当然你也可以增加@discardableResult声明，告诉编译器此方法可以不用接收返回值。
struct Caculator {
    func sum(a: Int,b: Int) -> Int {
        return a + b
    }
    
    @discardableResult
    func func1(a: Int,b: Int) ->Int {
        return a - b + 1
    }
}
let ca = Caculator()
ca.sum(a: 1, b: 2) // 此处会警告，因为方法有返回值但是没有接收
let _ = ca.sum(a: 1, b: 2) // 使用"_"接收无用返回值
ca.func1(a: 1, b: 2) // 由于func1添加了@discardableResult声明，即使不接收返回值也不会警告

// 可选类型
// Swift3.0对于可选类型控制更加严谨，隐式可选类型和其他类型的运算之后获得的是可选类型而不是隐式可选类型。
let a:Int! = 1
let b = a + 1 // 此时强制解包，b是Int型
let c = a // 注意此时c是Int? 在之前的Swift版本中c是Int！

// Selector的变化
// Selector的改变其实从1.0到3.0经历了多次变化，从最早的@Selector("method:")到现在的#selector(method(param1:))可以说经历了多次修改，好在它变得越来越好，毕竟字符串操作对于语法检查来说是很无助的。

class MyClass {
    @objc func sum(a: Int,b: Int) -> Int {
        return a + b
    }
    
    func func1(){
        let _ = #selector(sum(a:b:))
    }
}

// old: Swift 2.2
//class MyClass {
//    @objc func sum(a:Int,b:Int) -> Int {
//        return a + b
//    }
//
//    func func1(){
//        let _ = #selector(sum(_:b:))
//    }
//}

// 协议中的可选方法
// 在Swift3.0之前如果要定义协议中可选方法，只需要给协议加上@objc之后,方法使用optional修饰就可以了，但是Swift3.0中除了协议需要@objc修饰，可选方法也必须使用@objc来修饰。

@objc protocol MyProtocol {
    @objc optional func func1() //old: optional func func1()
    func func2()
}
// 取消++、--操作符

var d = 1
// d++ //报错,可以改写成 d += 1 或者 d = d + 1
// 取消C风格for循环

//for var i = 0 ;i < 10 ; i += 1 {
//    debugPrint(i)
//}
// 上面的代码会报错，可改写成如下代码
for i in 0  ..< 10  {
    debugPrint(i)
}

// SDK类库变化
// 大家都知道Swift诞生在Objective-C已经发展的相当成熟的情况下，为了保证ObjC开发人员顺利过渡到Swift，也因为Swift处于初级阶段，很多类库和方法命名都尽量和ObjC保持一致，在使用Swift开发iOS应用中处处可以看到ObjC的影子。但是作为一门Modern语言Swift还是做出了改变，从中可以看出日后Swift将彻底摆脱ObjC的影子。这其中包括重新导入Foundation消除类型前缀、方法名去重、函数和方法去C风格等等。
// 1.去掉前缀
let url1 = URL(string: "www.cmjstudio.com")
let isFileURL = url1?.isFileURL // old:url1.fileURL ，现在更加注重语意
let data1 = Data() //NSData

// 2.方法名使用动词，其他名词、介词等作为参数或移除
var array1 = [1,2,3]
array1.append(contentsOf: [4,5,6]) // old:array1.appendContentsOf([4,5,6])
array1.remove(at: 0) // old:array1.removeAtIndex(0)

// 3.不引起歧义的情况下尽量消除重复
let color1 = UIColor.red // old:var color1 = UIColor.redColor()

// 4.枚举成员首字母变成小写
let label1 = UILabel()
label1.textAlignment = .center // old:label1.textAlignment = .Center

// 5.按钮的Normal状态去掉
let btn1 = UIButton()
btn1.setTitle("hello", for: UIControlState()) // 相当于Normal状态

// 去C风格
// Swift发展初期很多类库的引入依然保持的ObjC风格，但是ObjC由于根出C语言，因此很多操作其实并不是对象和方法操作而是C语言的函数形式。到了Swift3.0之后这一现状将发生变化，全局函数将会变成某些类型的方法;某些常量定义将以某个枚举类型的成员来表示。
let rect1 = CGRect(x: 0, y: 0, width: 100, height: 100)
// 下面的代码将要报错，Swift3.0完全废除这种类C的风格
// let rect1 = CGRectMake(0, 0, 100, 100)

if let context1 = UIGraphicsGetCurrentContext() {
    CGContext.fillPath(context1) // old: CGContextFillPath(context1!)
}

// GCD的改变
let queue = DispatchQueue(label: "myqueue")
queue.async {
    debugPrint("hello world!")
}
// old:
//let queue = dispatch_queue_create("myqueue", nil)
//dispatch_async(queue) {
//    debugPrint("hello world!")
//}

// 相关常量定义被移到枚举内部
// NotificationCenter.defaultCenter().addObserver(self, selector: #selector(userDefaultChange()), name: UserDefaults.didChangeNotification, object: nil)
// old: NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(userDefaultChange()), name: NSUserDefaultsDidChangeNotification, object: nil)

// 集合API的变化
let array11 = [1, 2, 3]
let next = array11.index(after: 0)
// old: let start = array11.startIndex let next = start.successor()
// 增加新的方法
let first = array11.first { (element) -> Bool in
    element > 1
}

let r = Range(0..<3)
//old: let _ = NSRange(location: 0, length: 3)

// 下面的代码必须在控制器中执行，用于遍历当前view及其父视图
//for subview in sequence(first: self.view, next: { $0?.superview }){
//    debugPrint(subview)
//}

// 新的浮点协议
// Float、Double、CGFloat使用了新的协议，提供了提供 IEEE-754标准的属性和方法。

let aaa = 2 * Float.pi // old: let a = 2 * M_PI
let bbb = 2.0 * .pi // 注意前面是浮点型，后面可以省略Float
// 当然Swift3.0中还有一些其他的不常用变化，如果感兴趣可以访问Swift Proposals

// 从Swift2.2迁移到Swift3.0

// Swift的每次变化由于对之前的版本乃至上一个版本都不兼容造成每次Swift的升级都显得比较虐心，但是事实上这也是Swift的重大进步。记得之前曾有传闻说Swift3.0的语法和API都会稳定并且向上兼容，但是不久这个消息就破灭了，WWDC上官方也再次证实这个希望可能要到4.0才能实现。但是试想一下：Apple在很短的时间内就固话API对于Swift的发展真的是好事吗？毕竟新特性的加入、更好的语法优化才能让Swift越来越好！总的来说，如果应用要升级到Swift3.0可能要做不同程度的修改，但是这种改动仅仅是语法和SDK的变动并不会消耗太多的工作量，更何况Apple提供了迁移工具。

//取操作数,假设已经取到如下
let op1 = 1.1
let op2 = 2.2

func operate(operation: NSString) {
    switch operation {
    case "+":
        performOperation(operation: { $0 + $1 })
    default:
     return NSLog("error")
    }

}

func performOperation(operation: (Double, Double) -> Double) {
    
    let value = operation(op1, op2)

}


//
//let handle: ((Double, Double) -> Double)
//
//func operate(operation: NSString) {
//    
//    switch operation {
//    case "+": performOperation(operation: add)
//    case "-": performOperation(operation: subtract)
//    case "×": performOperation(operation: multiply)
//    case "÷": performOperation(operation: devide)
//    default: break
//    }
//}
////处理运算
//func performOperation(operation:(Double, Double) -> Double) {
//    let value = operation(op1, op2)
//    //operation(op1, op2)
//    //得到结果后的一些其他操作
//    NSLog("value = \(value)")
//}
//
////+
//func add(op1:Double, op2:Double) -> Double {
//    return op1 + op2
//}
////-
//func subtract(op1:Double, op2:Double) -> Double {
//    return op1 - op2
//}
////×
//func multiply(op1:Double, op2:Double) -> Double {
//    return op1 * op2
//}
////÷
//func devide(op1:Double, op2:Double) -> Double {
//    return op1 / op2
//}
//
//
